import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { MainLayout } from '@/shared/layouts/MainLayout/MainLayout.tsx';
import { MainPage } from '@/pages/MainPage';
import { NotFoundPage } from '@/pages/NotFoundPage';

const router = createBrowserRouter([
    {
        path: '/',
        element: <MainLayout />,
        children: [
            {
                path: '/',
                element: <MainPage />,
            },
        ],
    },
    {
        path: '*',
        element: <NotFoundPage />,
    },
]);

export const AppRouterProvider = () => {
    return <RouterProvider router={router} />;
};
