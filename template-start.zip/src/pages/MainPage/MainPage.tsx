const MainPage = () => {
    return (
        <div>
            <h1>Главная страницаы</h1>
        </div>
    );
};

export default MainPage;
