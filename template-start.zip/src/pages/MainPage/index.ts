export { MainPageAsync as MainPage } from './MainPage.async.tsx';
