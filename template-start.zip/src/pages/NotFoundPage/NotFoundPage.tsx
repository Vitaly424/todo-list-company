const NotFoundPage = () => {
    return (
        <div>
            <p>Такой страницы не существует</p>
        </div>
    );
};

export default NotFoundPage;
