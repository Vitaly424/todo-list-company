export { NotFoundPageAsync as NotFoundPage } from './NotFoundPage.async.tsx';
