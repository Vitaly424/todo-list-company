import { lazy } from 'react';

export const NotFoundPageAsync = lazy(() => import('./NotFoundPage'));
