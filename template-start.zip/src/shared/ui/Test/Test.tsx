import cls from './Test.module.scss';

// interface TestProps {}

export const Test = () => {
    // const {} = props;

    return (
        <div className={cls.test}>
            Тест
        </div>
    );
};
