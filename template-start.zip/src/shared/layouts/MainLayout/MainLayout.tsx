import { Header } from '../Header/Header.tsx';
import { Outlet } from 'react-router-dom';
import { Suspense } from 'react';

export const MainLayout = () => {
    return (
        <>
            <Header />

            <Suspense fallback={<p>Загрузка...</p>}>
                <Outlet />
            </Suspense>
        </>
    );
};
