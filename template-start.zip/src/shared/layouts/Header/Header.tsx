export const Header = () => {
    return <header></header>;
};
